from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from ..models.client import Client
from ..models import db
import re

# Define the authentication blueprint
auth = Blueprint('auth', __name__)

# Regex patterns for validation
PHONE_REGEX = r'^\\+?1?\\d{9,15}$'
VIN_REGEX = r'^[A-HJ-NPR-Z0-9]{17}$'

# -----------------------------
# Registration Route
# -----------------------------
@auth.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handles client registration with form validation and regex checks.
    """
    if request.method == 'POST':
        email = request.form.get('email')
        name = request.form.get('name')
        phone = request.form.get('phone')
        licence_plate = request.form.get('licence_plate')
        vin_number = request.form.get('vin_number')
        password = request.form.get('password')

        # Regex validation
        if not re.match(PHONE_REGEX, phone):
            flash('Invalid phone number format.')
            return redirect(url_for('auth.register'))
        if not re.match(VIN_REGEX, vin_number):
            flash('Invalid VIN number format.')
            return redirect(url_for('auth.register'))

        # Check if user exists
        user = Client.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.')
            return redirect(url_for('auth.register'))

        # Create new user
        new_user = Client(
            email=email,
            name=name,
            phone=phone,
            licence_plate=licence_plate,
            vin_number=vin_number,
            password=generate_password_hash(password, method='sha256')
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful. Please login.')
        return redirect(url_for('auth.login'))

    return render_template('register.html')


# -----------------------------
# Login Route
# -----------------------------
@auth.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handles client login and session management.
    """
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = Client.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('main.profile'))
        flash('Invalid credentials.')
    return render_template('login.html')


# -----------------------------
# Logout Route
# -----------------------------
@auth.route('/logout')
@login_required
def logout():
    """
    Handles user logout.
    """
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('main.index'))