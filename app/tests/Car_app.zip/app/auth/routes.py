from flask import Blueprint, render_template, redirect, url_for, flash, request
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required
from app.db_setup import db
from ..models.employee import Employee
from app.models.client import Client
from datetime import datetime
import pytz # East European Timezone support

# Blueprint for authentication
auth = Blueprint('auth', __name__)
eet = pytz.timezone('Europe/Bucharest')  # East European Time (Winter)

# Regex patterns
PHONE_REGEX = r'^\\+?1?\\d{9,15}$'
VIN_REGEX = r'^[A-HJ-NPR-Z0-9]{17}$'

# Client Registration Route
@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        address = request.form.get('address')
        vin_number = request.form.get('vin_number')
        car_model = request.form.get('car_model')
        password = request.form.get('password')

        # Validation for all required fields
        if not all([name, email, phone, address, vin_number, car_model, password]):
            flash('All fields are required. Please fill in all the details.', 'error')
            return redirect(url_for('auth.register'))

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
        new_user = Client(
            name=name,
            email=email,
            phone=phone,
            address=address,
            vin_number=vin_number,
            car_model=car_model,
            registration_date=datetime.now(eet),
            password=hashed_password
        )
        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully! ✅')
        return redirect(url_for('auth.login'))

    return render_template('register.html')


# Login Route for Clients and Employees
@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Check in Client and Employee tables
        user = Client.query.filter_by(email=email).first()
        if user is None:
            user = Employee.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash('Logged in successfully!')
            if isinstance(user, Employee):
                # Redirect based on employee role
                if user.role == 'Manager':
                    return redirect(url_for('employee.manager_dashboard'))
                elif user.role == 'Mechanic':
                    return redirect(url_for('employee.mechanic_dashboard'))
                elif user.role == 'StockKeeper':
                    return redirect(url_for('employee.stockkeeper_dashboard'))
                elif user.role == 'Receptionist':
                    return redirect(url_for('employee.receptionist_dashboard'))
            return redirect(url_for('main.index')) # 🔄 Redirect after login
        else:
            flash('Invalid credentials. Please try again.')

    return render_template('login.html')


# Logout Route
@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('auth.login'))