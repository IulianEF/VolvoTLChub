from app.db_setup import create_app

app = create_app()