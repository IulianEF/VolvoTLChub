from app.db_setup import db, create_app
from app.models.elevator import Elevator
import os


app = create_app()

# ✅ Create instance folder if not exists (in root)
os.makedirs(app.instance_path, exist_ok=True)

with app.app_context():
    db.drop_all()  # 🔄 Reset database
    db.create_all()  # ✅ Create all tables
    print("📦 Database successfully created at instance/volvo_tlc_hub.db!")

    # Seed Elevator
    elevators = [Elevator(type='Standard', status='Available'),
                 Elevator(type='Heavy-Duty', status='Available')]
    db.session.add_all(elevators)
    db.session.commit()
    print("✅ Elevators seeded successfully.")