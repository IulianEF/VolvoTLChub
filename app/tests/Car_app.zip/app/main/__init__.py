# app/main/__init__.py - Main blueprint configuration

from flask import Blueprint

# Define the main blueprint
main = Blueprint('main', __name__)

# Import routes after defining the blueprint to avoid circular imports
from . import routes