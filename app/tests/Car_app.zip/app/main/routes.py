from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime
import pytz



def create_main_blueprint(db, Repair, Elevator):
    main = Blueprint('main', __name__)
    eet = pytz.timezone('Europe/Bucharest')

    @main.route('/')
    def index():
        return render_template('index.html')

    @main.route('/schedule_repair', methods=['GET', 'POST'])
    @login_required
    def schedule_repair():
        available_elevators = db.session.query(Elevator).filter_by(status='Available').all()
        if request.method == 'POST':
            description = request.form.get('description')
            scheduled_date = request.form.get('scheduled_date')
            elevator_id = request.form.get('elevator_id')

            if not all([description, scheduled_date, elevator_id]):
                flash('All fields are required.', 'error')
                return redirect(url_for('main.schedule_repair'))

            elevator = Elevator.query.get(elevator_id)
            if elevator.status != 'Available':
                flash('Elevator not available. Select another one.', 'error')
                return redirect(url_for('main.schedule_repair'))

            elevator.status = 'Occupied'
            new_repair = Repair(
                client_id=current_user.id,
                description=description,
                elevator_id=elevator_id,
                scheduled_date=datetime.strptime(scheduled_date, '%Y-%m-%d').replace(tzinfo=eet)
            )
            db.session.add(new_repair)
            db.session.commit()
            flash('Repair scheduled successfully ✅')
            return redirect(url_for('main.index'))

        return render_template('schedule_repair.html', elevators=available_elevators)


    @main.route('/profile')
    @login_required
    def profile():
        """📝 Displays the user's profile information."""
        return render_template('profile.html', user=current_user)

    return main


