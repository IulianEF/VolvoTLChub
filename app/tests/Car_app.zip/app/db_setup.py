from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# from flask_login import LoginManager
import os
from app.extensions import db, login_manager

# from app.models import Employee
#
# # ✅ Create single instances of SQLAlchemy and LoginManager
# db = SQLAlchemy()
# login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'your_secret_key'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(app.instance_path, "volvo_tlc_hub.db")}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # ✅ Ensure instance folder exists
    os.makedirs(app.instance_path, exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  # Redirect unauthorized users


    # ✅ Import models for db.create_all()
    from app.models.employee import Employee
    from app.models.repair import Repair
    from app.models.elevator import Elevator
    from app.main.routes import create_main_blueprint


    # ✅ Auto-create DB if missing
    with app.app_context():
        if not os.path.exists(os.path.join(app.instance_path, 'volvo_tlc_hub.db')):
            db.create_all()
            print("✅ Database auto-created at instance/volvo_tlc_hub.db")

            # 🚀 Seed initial elevators
            seed_elevators()

    # ✅ User loader for Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        return Employee.query.get(int(user_id))

    # ✅ Register blueprints
    main_blueprint = create_main_blueprint(db, Repair, Elevator)
    app.register_blueprint(main_blueprint)

    from app.auth.routes import auth as auth_blueprint
    app.register_blueprint(auth_blueprint, url_prefix='/auth')

    from app.employee.routes import employee as employee_blueprint
    app.register_blueprint(employee_blueprint, url_prefix='/employee')

    return app


def seed_elevators():
    """🚀 Seed initial elevators if none exist."""
    from app.models.elevator import Elevator

    if Elevator.query.count() == 0:
        elevators = [
            Elevator(type='Standard', status='Available'),
            Elevator(type='Heavy-Duty', status='Available')
        ]
        db.session.add_all(elevators)
        db.session.commit()
        print("✅ Elevators seeded successfully.")