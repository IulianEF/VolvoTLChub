# app/utils.py - Utility functions for the Volvo Mending Service

from functools import wraps
from flask import abort
from flask_login import current_user, LoginManager
from app.models.client import Client
from app.models.employee import Employee

# Initialize LoginManager
login_manager = LoginManager()

@login_manager.user_loader
def load_user(user_id):
    """
    Load user for Flask-Login. Checks both Client and Employee tables.
    """
    user = Client.query.get(int(user_id))
    if user is None:
        user = Employee.query.get(int(user_id))
    return user

def role_required(role):
    """
    Custom decorator for role-based access control.
    Usage: @role_required('Manager')
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(current_user, 'is_authenticated'):
                abort(500, description="current_user is not properly loaded. Check Flask-Login configuration.")
            if not current_user.is_authenticated or current_user.role != role:
                abort(403)  # Forbidden
            return f(*args, **kwargs)
        return decorated_function
    return decorator