import pandas as pd
import numpy as np
from flask import render_template, request, jsonify
from datetime import datetime, timedelta
from flask_login import login_required
from app.utils import role_required
from werkzeug.security import generate_password_hash
from app.models.employee import Employee
from app.models.repair import Repair
from app.models.elevator import Elevator
from app.models import db
from app.models.consumable import Consumable
from . import employee

# -----------------------------
# Employee Dashboards
# -----------------------------

@employee.route('/manager_dashboard')
@login_required
@role_required('Manager')
def manager_dashboard():
    return render_template('manager_dashboard.html', title="Manager Dashboard", description="Manage employees, view revenue reports, and oversee operations.")

@employee.route('/mechanic_dashboard')
@login_required
@role_required('Mechanic')
def mechanic_page():
    return render_template('mechanic_dashboard.html', title="Mechanic Dashboard", description="View assigned repairs and update repair statuses.")

@employee.route('/stockkeeper_dashboard')
@login_required
@role_required('StockKeeper')
def stockkeeper_page():
    return render_template('stockkeeper_dashboard.html', title="Stockkeeper Dashboard", description="Monitor and replenish parts inventory.")

@employee.route('/receptionist_dashboard')
@login_required
@role_required('Receptionist')
def receptionist_page():
    return render_template('receptionist_dashboard.html', title="Receptionist Dashboard", description="Approve repairs, schedule appointments, and manage client interactions.")

@employee.route('/dashboard')
@login_required
def dashboard():
    """Employee dashboard displaying role-based functionalities."""
    return render_template('employee_dashboard.html')

# -----------------------------
# Revenue Report (Manager Only)
# -----------------------------

@employee.route('/revenue_report')
@login_required
@role_required('Manager')
def revenue_report():
    repairs = Repair.query.all()
    data = [{'id': r.id, 'status': r.status, 'date': r.scheduled_date} for r in repairs]
    df = pd.DataFrame(data)
    df['count'] = 1
    report = df.groupby('status')['count'].sum()
    total_revenue = np.sum(report) * 100

    return render_template('revenue_report.html', total_revenue=total_revenue, report=report.to_dict())

# -----------------------------
# Repair Management (Receptionist & Mechanic)
# -----------------------------

@employee.route('/approve_repair/<int:repair_id>', methods=['POST'])
@login_required
@role_required('Receptionist')
def approve_repair(repair_id):
    repair = Repair.query.get(repair_id)
    if repair:
        repair.status = 'approved'
        db.session.commit()
        return jsonify({'message': 'Repair approved successfully!'}), 200
    return jsonify({'message': 'Repair not found.'}), 404

@employee.route('/complete_repair/<int:repair_id>', methods=['POST'])
@login_required
@role_required('Mechanic')
def complete_repair(repair_id):
    repair = Repair.query.get(repair_id)
    if repair and repair.status == 'approved':
        repair.status = 'completed'
        repair.completion_date = datetime.utcnow()
        db.session.commit()
        return jsonify({'message': 'Repair marked as completed.'}), 200
    return jsonify({'message': 'Repair not found or not approved.'}), 404

# -----------------------------
# Employee Management (Manager)
# -----------------------------

@employee.route('/manage_employee', methods=['POST'])
@login_required
@role_required('Manager')
def manage_employee():
    action = request.form.get('action')
    employee_id = request.form.get('employee_id')

    if action == 'create':
        new_employee = Employee(
            name=request.form.get('name'),
            role=request.form.get('role'),
            employment_date=datetime.strptime(request.form.get('employment_date'), '%Y-%m-%d'),
            salary=float(request.form.get('salary')),
            password=generate_password_hash(request.form.get('password'), method='sha256')
        )
        db.session.add(new_employee)
        db.session.commit()
        return jsonify({'message': 'Employee created successfully!'}), 201

    elif action == 'update':
        employee = Employee.query.get(employee_id)
        if employee:
            employee.name = request.form.get('name')
            employee.salary = float(request.form.get('salary'))
            db.session.commit()
            return jsonify({'message': 'Employee updated successfully!'}), 200
        return jsonify({'message': 'Employee not found.'}), 404

    elif action == 'delete':
        employee = Employee.query.get(employee_id)
        if employee:
            db.session.delete(employee)
            db.session.commit()
            return jsonify({'message': 'Employee deleted successfully!'}), 200
        return jsonify({'message': 'Employee not found.'}), 404

# -----------------------------
# Elevator Management (Manager)
# -----------------------------

@employee.route('/block_elevator/<int:elevator_id>', methods=['POST'])
@login_required
@role_required('Manager')
def block_elevator(elevator_id):
    duration = request.form.get('duration')
    elevator = Elevator.query.get(elevator_id)
    if elevator:
        if duration == 'half_day':
            elevator.blocked_until = datetime.utcnow() + timedelta(hours=12)
        elif duration == 'full_day':
            elevator.blocked_until = datetime.utcnow() + timedelta(days=1)
        elif duration == 'week':
            elevator.blocked_until = datetime.utcnow() + timedelta(weeks=1)
        elif duration == 'month':
            elevator.blocked_until = datetime.utcnow() + timedelta(days=30)
        db.session.commit()
        return jsonify({'message': 'Elevator blocked successfully!'}), 200
    return jsonify({'message': 'Elevator not found.'}), 404

# -----------------------------
# Stock Management (StockKeeper)
# -----------------------------

@employee.route('/check_stock')
@login_required
@role_required('StockKeeper')
def check_stock():
    consumables = Consumable.query.all()
    low_stock_items = [item for item in consumables if item.quantity <= item.threshold]
    return render_template('low_stock_alerts.html', low_stock_items=low_stock_items)

@employee.route('/replenish_stock', methods=['POST'])
@login_required
@role_required('StockKeeper')
def replenish_stock():
    consumables = Consumable.query.all()
    replenished_items = []

    for item in consumables:
        if item.quantity <= item.threshold:
            item.quantity += item.reorder_amount
            replenished_items.append(item.name)

    db.session.commit()
    return jsonify({'message': 'Stock replenished for items:', 'items': replenished_items}), 200