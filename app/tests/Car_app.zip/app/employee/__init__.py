# __init__.py - Employee blueprint
from flask import Blueprint


employee = Blueprint('employee', __name__)


from . import routes
