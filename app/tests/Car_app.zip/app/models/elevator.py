from app.extensions import db

class Elevator(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='Available', nullable=False)
    blocked_until = db.Column(db.DateTime, nullable=True)
