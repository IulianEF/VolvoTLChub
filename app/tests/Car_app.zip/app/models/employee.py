from app.extensions import db
from flask_login import UserMixin

class Employee(UserMixin, db.Model):
    __tablename__ = 'employee'
    __table_args__ = {'extend_existing': True}

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    role = db.Column(db.String(50), nullable=False)
    employment_date = db.Column(db.Date, nullable=False)
    salary = db.Column(db.Float, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Manager(Employee):
    department = db.Column(db.String(100))

class Mechanic(Employee):
    specialization = db.Column(db.String(100))

class Receptionist(Employee):
    shift = db.Column(db.String(50))

class StockKeeper(Employee):
    warehouse_section = db.Column(db.String(100))
