from app.extensions import db

class Consumable(db.Model):
    __tablename__ = 'consumables'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200))
    quantity = db.Column(db.Integer, nullable=False)
    threshold = db.Column(db.Integer, nullable=False)  # Minimum quantity before replenishment alert
    reorder_amount = db.Column(db.Integer, nullable=False)  # Default quantity to reorder
    price_per_unit = db.Column(db.Float, nullable=False)  # For cost calculations
    last_replenished = db.Column(db.DateTime)

    def __repr__(self):
        return f'<Consumable {self.name} - Quantity: {self.quantity}>'
