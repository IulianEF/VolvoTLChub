from app.extensions import db
from flask_login import UserMixin

class Client(UserMixin, db.Model):
    __tablename__ = 'client'
    __table_args__ = {'extend_existing': True} # ✅ Prevents duplicate table conflict

    """
        Client model representing client details and their car history.
        """
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(150), nullable=False)
    vin_number = db.Column(db.String(20), unique=True, nullable=False)
    car_model = db.Column(db.String(100), nullable=False)
    registration_date = db.Column(db.DateTime, nullable=False)
    password = db.Column(db.String(150), nullable=False)