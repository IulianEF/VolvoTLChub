from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import all models with corrected paths and references
from .repair import Repair
from .client import Client
from .employee import Employee, Manager, Mechanic, StockKeeper
from .elevator import Elevator
from .consumable import Consumable  # Added Consumable import for stock management


#list for streamlined wildcard imports.
__all__ = [
    "db",
    "Repair",
    "Client",
    "Employee",
    "Manager",
    "Mechanic",
    "StockKeeper",
    "Elevator",
    "Consumable"
]