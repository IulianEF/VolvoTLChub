from app.extensions import db

class Repair(db.Model):
    """
    Repair model representing repair details linked to clients and employees.
    """
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('client.id'), nullable=False)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id'), nullable=False)
    scheduled_date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(50), default='pending')
    cost = db.Column(db.Float)
    billing_details = db.Column(db.String(300))
    description = db.Column(db.String(255), nullable=False)
    elevator_id = db.Column(db.Integer, nullable=False)