from app.db_setup import db, create_app
from app.models.employee import Manager, Receptionist, Mechanic, StockKeeper
from werkzeug.security import generate_password_hash
from datetime import datetime
import pytz
import os

# ✅ Set East European Time (Winter)
eet = pytz.timezone('Europe/Bucharest')

# ✅ Ensure instance folder exists
os.makedirs(os.path.join(os.getcwd(), 'instance'), exist_ok=True)

app = create_app()

with app.app_context():
    # ✅ Drop and recreate the database
    db.drop_all()
    db.create_all()
    print("🔄 Database reset successfully.")

    # ✅ Add predefined employees (Removed department, fixed datetime)
    employees = [
        Manager(
            name="WinstonScott",
            email="manager@volvo.com",
            role="Manager",
            employment_date=datetime.now(eet),
            salary=7000,
            password=generate_password_hash("manager123", method='scrypt')
        ),
        Receptionist(
            name="Charon",
            email="receptionist@volvo.com",
            role="Receptionist",
            employment_date=datetime.now(eet),
            salary=4000,
            password=generate_password_hash("reception123", method='scrypt')
        ),
        Mechanic(
            name="JohnWick",
            email="mechanic@volvo.com",
            role="Mechanic",
            employment_date=datetime.now(eet),
            salary=5000,
            password=generate_password_hash("mechanic123", method='scrypt')
        ),
        StockKeeper(
            name="Sommelier",
            email="stockkeeper@volvo.com",
            role="StockKeeper",
            employment_date=datetime.now(eet),
            salary=4500,
            password=generate_password_hash("stockkeeper123", method='scrypt')
        )
    ]

    # ✅ Commit employees to the database
    db.session.add_all(employees)
    db.session.commit()
    print("✅ Employees added successfully.")
